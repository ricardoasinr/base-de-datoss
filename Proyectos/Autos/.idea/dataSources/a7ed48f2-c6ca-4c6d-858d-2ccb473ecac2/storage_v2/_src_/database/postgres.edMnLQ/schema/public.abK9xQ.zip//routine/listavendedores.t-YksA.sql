create function listavendedores() returns SETOF vendedor
    language sql
as
$$
select * from vendedor;

$$;

alter function listavendedores() owner to postgres;

